﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrometricChallenge
{
    public class Circle : Shape
    {
        private double radius;

        public Circle(int radius)
        {
            this.radius = radius;
        }

        public override string Name
        {
            get { return "Circle"; }
        }

        public override double SurfaceArea
        {
            get { return Math.PI * radius * radius; }
        }

        public override double Perimeter
        {
            get { return 2 * Math.PI * radius; }
        }

        public override string Description
        {
            get
            {
                return $"{Name} with a radius of {radius}, area of {Math.Round(SurfaceArea)} and perimeter of {Math.Round(Perimeter)}";
            }
        }
    }
}
