﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrometricChallenge
{
    class Program
    {
        static void Main(string[] args)
        {
            var shapes = new List<Shape>()
            {
                new Circle(8),
                new Triangle(8, 8, 8),
                new Triangle(8, 3, 3),
                new Triangle(8, 6, 3),
                new Square(6),
                new Rectangle(3, 6)
            };

            Console.WriteLine("-------------------------------");
            Console.WriteLine("--------DISPLAY SHAPES---------");
            Console.WriteLine("-------------------------------");

            foreach (var shape in shapes)
            {
                Console.WriteLine(shape);
            }

            Console.Read();
        }
    }
}
