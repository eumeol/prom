﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrometricChallenge
{
    public class Rectangle : Shape
    {
        private int width;
        private int length;

        public Rectangle(int width, int length) 
        {
            this.width = width;
            this.length = length;
        }

        public override string Name
        {
            get { return "Rectangle"; }
        }

        public override double SurfaceArea
        {
            get { return width * length; }
        }

        public override double Perimeter
        {
            get { return (width + length) * 2; }
        }

        public override string Description
        {
            get
            {
                return $"{Name} with a width of {width} and length of {length}";
            }
        }
    }
}
