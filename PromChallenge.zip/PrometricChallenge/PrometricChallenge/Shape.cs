﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrometricChallenge
{
    public abstract class Shape
    {
        public abstract string Name { get; }
        public abstract double Perimeter { get; }
        public abstract double SurfaceArea { get; }

        public virtual string Description
        {
            get { return $"{Name} with an area of {SurfaceArea} and perimeter of {Perimeter}"; }
        }

        public override string ToString()
        {
            return $"Shape : {Description}";
        }
    }
}
