﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrometricChallenge
{
    public class Square : Shape
    {
        private int width;

        public Square(int width) 
        {
            this.width = width;
        }

        public override string Name
        {
            get { return "Square"; }
        }

        public override double Perimeter
        {
            get
            {
                 return (width + width) * 2; 
            }
            
        }

        public override double SurfaceArea
        {
            get
            {
                return Math.Pow(width, 2);
            }
        }      

    }
}
