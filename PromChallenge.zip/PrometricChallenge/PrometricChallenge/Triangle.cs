﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrometricChallenge
{
    public class Triangle : Shape
    {
        private int height;
        private int hypotenuse;
        private int triangleBase;

        public Triangle(int height, int triangleBase, int hypotenuse)
        {
            this.height = height;
            this.hypotenuse = hypotenuse;
            this.triangleBase = triangleBase;
        }

        public override double SurfaceArea
        {
            get { return (height * triangleBase) / 2; }
        }

        public override double Perimeter
        {
            get
            {
                return height + triangleBase + hypotenuse;
            }
        }


        public override string Name
        {
            get
            {
                if (height == triangleBase &&
                    hypotenuse == triangleBase)
                {
                    return "Equilateral";
                }
                else if (height == triangleBase ||
                         height == hypotenuse ||
                         hypotenuse == triangleBase)
                {
                    return "Isosceles";
                }
                else
                {
                    return "Scalene";
                }

            }
        }

        public override string Description
        {
            get
            {
                return $"A triangle with a height of {height}, base of {triangleBase} and hypotenuse of {hypotenuse} is an {Name}";
            }
        }
    }
}
