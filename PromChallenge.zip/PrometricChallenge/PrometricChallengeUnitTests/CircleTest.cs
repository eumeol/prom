﻿using NUnit.Framework;
using PrometricChallenge;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrometricChallengeUnitTests
{
    [TestFixture]
    public class CircleTest
    {
        [Test]
        public void Name_WhenCalled_WillReturn_Circle()
        {
            var radius = 8;
            var circle = MakeCircle(radius);
            var expected = "Circle";

            var actual = circle.Name;

            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void SurfaceArea_GivenRadius_8_WillReturn_201()
        {
            var radius = 8;
            var circle = MakeCircle(radius);
            var expected = 201.0d;

            var actual = Math.Round(circle.SurfaceArea);

            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void Perimeter_GivenRadius_8_WillReturn_50()
        {
            var radius = 8;
            var circle = MakeCircle(radius);
            var expected = 50.0d;

            var actual = Math.Round(circle.Perimeter);

            Assert.AreEqual(expected, actual);
        }

        private Circle MakeCircle(int radius)
        {
            return new Circle(radius);
        }

    }
}
