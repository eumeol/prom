﻿using NUnit.Framework;
using PrometricChallenge;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrometricChallengeUnitTests
{
    [TestFixture]
    public class RectangleTest
    {
        [Test]
        public void Name_WhenCalled_WillReturn_Rectangle()
        {
            var width = 8;
            var length = 3;
            var rectangle = MakeRectangle(width, length);
            var expected = "Rectangle";

            var actual = rectangle.Name;

            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void SurfaceArea_GivenWidth8Length3_WillReturn_24()
        {
            var width = 8;
            var length = 3;
            var rectangle = MakeRectangle(width, length);
            var expected = 24.0d;

            var actual = rectangle.SurfaceArea;

            Assert.AreEqual(expected, actual);
        }

        [Test]
        public void Perimeter_GivenWidth8Length3_WillReturn_22()
        {
            var width = 8;
            var length = 3;
            var rectangle = MakeRectangle(width, length);
            var expected = 22.0d;

            var actual = rectangle.Perimeter;

            Assert.AreEqual(expected, actual);
        }

        private Rectangle MakeRectangle(int width, int length)
        {
            return new Rectangle(width, length);
        }
        
    }
}

