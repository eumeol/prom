﻿using NUnit.Framework;
using PrometricChallenge;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrometricChallengeUnitTests
{
    [TestFixture]
    public class TriangleTest
    {
        [TestCase(8, 8, 8, "Equilateral")]
        [TestCase(8, 6, 6, "Isosceles")]
        [TestCase(8, 3, 6, "Scalene")]
        public void Name_WhenCalledWithVariousSides_WillReturnCorrectType(
            int triBase, int height, int hypotenuse, string expected)
        {
            var triangle = MakeTriangle(triBase, height, hypotenuse);

            var actual = triangle.Name;

            Assert.AreEqual(expected, actual);
        }

        private Triangle MakeTriangle(
            int triBase, int height, int hypotenuse)
        {
            return new Triangle(height, triBase, hypotenuse);
        }
    }
}
